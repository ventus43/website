# 밭 — 섭외 관리 (Vite / Vanilla JS)

교회 전도팀 섭외 스프레드시트를 대체하는 웹 앱. 프레임워크 없이 순수 JS + Vite로 구성.

## 실행

```bash
npm install
npm run dev
```

`.env.example` 을 `.env` 로 복사하고 `VITE_API_BASE_URL` 을 실제 백엔드 주소로 지정하세요.
백엔드가 아직 없다면 `vite.config.js` 의 `server.proxy['/api'].target` 을 로컬 목업 서버 주소로 바꿔서 사용할 수 있습니다.

## 폴더 구조

```
index.html          엔트리 HTML (탭 3개 마크업 포함)
src/
  main.js            탭 전환 + 각 탭 초기화 부트스트랩
  api.js             REST API 통신 레이어 (백엔드 연동 지점)
  utils.js           날짜 포맷 등 공통 유틸
  style.css          전체 스타일
  tabs/
    outreach.js       섭외 리스트 탭 (조회/추가/삭제)
    schedule.js        일정 관리 탭 (조회/추가/삭제)
    check.js           점검 현황 탭 (읽기 전용)
```

## 백엔드에 요청할 API 스펙

| Method | Path                | 설명 |
|---|---|---|
| GET    | /api/outreach       | 섭외 리스트 전체 조회 |
| POST   | /api/outreach       | 섭외 항목 추가 |
| PATCH  | /api/outreach/:id   | 일정(date) 또는 진행 상태(status) 부분 수정 |
| DELETE | /api/outreach/:id   | 섭외 항목 삭제 |
| GET    | /api/schedule       | 일정 전체 조회 |
| POST   | /api/schedule       | 일정 추가 |
| DELETE | /api/schedule/:id   | 일정 삭제 |
| GET    | /api/check          | 점검 현황 조회 (읽기 전용) |

### OutreachEntry
```json
{
  "id": 1,
  "date": "2026-08-09",
  "zone": "4+7",
  "name": "최미슬",
  "counselor1": "김상담",
  "counselor2": null,
  "place": "15시, 상무역 앞 스타벅스",
  "goal": "첫만남",
  "status": "ongoing"
}
```
- `counselor1`(상담자)은 필수, `counselor2`(가섭)는 선택.
- `status` 는 `ongoing`(진행) 또는 `stopped`(중단).

### ScheduleEntry
```json
{ "id": 1, "date": "2026-08-11", "time": "19:00", "title": "조유민 — 차후 만남", "place": "전대", "memo": "" }
```

### CheckEntry (읽기 전용)
```json
{
  "date": "2026.06.27", "zone": "6+7", "name": "김이준", "tm": "O",
  "check1": "대화중", "check2": "비합", "check3": "비합",
  "status": "중단", "note": "중단"
}
```

## 현재 동작 방식 (백엔드 연결 전)

- 목록 조회(GET)가 실패하면 화면에 에러 배너를 보여주고 빈 상태로 둡니다.
- 추가(POST)가 실패하면 화면에는 우선 반영하되(낙관적 업데이트) 새로고침 시 사라진다는 안내를 폼 하단에 표시합니다. 실제 백엔드 연결 후에는 이 폴백이 자연히 사라집니다.
- 섭외 리스트의 진행 상태(진행/중단 배지)는 클릭하면 바로 토글되고, 일정(📅 날짜)도 클릭하면 날짜 선택기가 열려 바로 변경됩니다. 둘 다 PATCH로 즉시 반영되며, 실패 시 화면을 원래 값으로 되돌립니다.

## 다음 작업

- [ ] 백엔드 API 서버 구축 (REST, 위 스펙 참고)
- [ ] 인증/세션 처리 (교회 내부 사용자 로그인)
- [ ] 점검 현황 탭에 필터/검색 추가
- [ ] 섭외 리스트 검색/구역 필터
