// ---------------------------------------------------------------------------
// 백엔드 API 연동 레이어.
// 새 백엔드(API 서버)의 베이스 URL은 .env 의 VITE_API_BASE_URL 로 지정합니다.
// (개발 중에는 vite.config.js 의 proxy 설정으로 /api -> 실제 서버로 전달됩니다.)
//
// 기대하는 REST 스펙 (백엔드 팀과 합의 필요):
//
//   GET    /api/outreach              -> OutreachEntry[]
//   POST   /api/outreach              -> OutreachEntry   (body: OutreachInput)
//   PATCH  /api/outreach/:id          -> OutreachEntry   (body: Partial<OutreachInput>, 일정/상태 변경용)
//   DELETE /api/outreach/:id          -> 204
//
//   GET    /api/schedule              -> ScheduleEntry[]
//   POST   /api/schedule              -> ScheduleEntry   (body: ScheduleInput)
//   DELETE /api/schedule/:id          -> 204
//
//   GET    /api/check                 -> CheckEntry[]    (읽기 전용)
//
// OutreachEntry {
//   id, date, zone, name,
//   counselor1 (필수), counselor2 (선택, nullable),
//   place, goal, status: 'ongoing' | 'stopped'
// }
// ScheduleEntry { id, date, time, title, place, memo }
// CheckEntry { date, zone, name, tm, check1, check2, check3, status, note }
// ---------------------------------------------------------------------------

const BASE_URL = import.meta.env.VITE_API_BASE_URL || '/api';

async function request(path, options = {}) {
  const res = await fetch(`${BASE_URL}${path}`, {
    headers: { 'Content-Type': 'application/json' },
    ...options,
  });

  if (!res.ok) {
    let message = `요청 실패 (${res.status})`;
    try {
      const body = await res.json();
      if (body?.message) message = body.message;
    } catch (_) { /* 응답이 JSON이 아닌 경우 무시 */ }
    throw new Error(message);
  }

  if (res.status === 204) return null;
  return res.json();
}

export const outreachApi = {
  list: () => request('/outreach'),
  create: (input) => request('/outreach', { method: 'POST', body: JSON.stringify(input) }),
  update: (id, patch) => request(`/outreach/${id}`, { method: 'PATCH', body: JSON.stringify(patch) }),
  remove: (id) => request(`/outreach/${id}`, { method: 'DELETE' }),
};

export const scheduleApi = {
  list: () => request('/schedule'),
  create: (input) => request('/schedule', { method: 'POST', body: JSON.stringify(input) }),
  remove: (id) => request(`/schedule/${id}`, { method: 'DELETE' }),
};

export const checkApi = {
  list: () => request('/check'),
};
