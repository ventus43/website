import './style.css';
import { initOutreachTab } from './tabs/outreach.js';
import { initScheduleTab } from './tabs/schedule.js';
import { initCheckTab } from './tabs/check.js';

const TAB_NAMES = ['outreach', 'schedule', 'check'];

function setupTabs() {
  document.querySelectorAll('.tab').forEach((tab) => {
    tab.addEventListener('click', () => {
      document.querySelectorAll('.tab').forEach((t) => t.classList.remove('active'));
      tab.classList.add('active');
      TAB_NAMES.forEach((name) => {
        document.getElementById(`panel-${name}`).style.display =
          name === tab.dataset.tab ? 'block' : 'none';
      });
    });
  });
}

async function main() {
  setupTabs();
  // 세 탭 모두 초기 데이터를 병렬로 불러옵니다.
  await Promise.all([initOutreachTab(), initScheduleTab(), initCheckTab()]);
}

main();
