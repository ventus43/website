import { outreachApi } from '../api.js';
import { fmtDateLabel, groupBy } from '../utils.js';

let entries = [];
let loadFailed = false;

const els = {};

function cacheEls() {
  els.groups = document.getElementById('outreach-groups');
  els.count = document.getElementById('count-outreach');
  els.form = document.getElementById('outreach-form');
  els.toggleBtn = document.getElementById('toggle-outreach-form');
  els.cancelBtn = document.getElementById('cancel-outreach');
  els.saveBtn = document.getElementById('save-outreach');
  els.error = document.getElementById('outreach-error');
  els.date = document.getElementById('of-date');
  els.zone = document.getElementById('of-zone');
  els.name = document.getElementById('of-name');
  els.c1 = document.getElementById('of-counselor1');
  els.c2 = document.getElementById('of-counselor2');
  els.place = document.getElementById('of-place');
  els.goal = document.getElementById('of-goal');
  els.status = document.getElementById('of-status');
}

function render() {
  els.count.textContent = entries.length;

  if (loadFailed && entries.length === 0) {
    els.groups.innerHTML = `<div class="error-banner">섭외 목록을 불러오지 못했습니다. API 서버 연결을 확인해 주세요.</div>`;
    return;
  }

  if (entries.length === 0) {
    els.groups.innerHTML = '<div class="empty">등록된 섭외 기록이 없습니다. 위 + 버튼으로 추가해 보세요.</div>';
    return;
  }

  const groups = groupBy(entries, (e) => e.date);
  const sortedDates = Object.keys(groups).sort();

  els.groups.innerHTML = sortedDates.map((date) => {
    const rows = groups[date].map((e) => {
      const chips = [`<span class="chip required">${e.counselor1 || '미지정'}</span>`];
      if (e.counselor2) chips.push(`<span class="chip optional">${e.counselor2}</span>`);
      return `
        <div class="entry-card" data-id="${e.id}">
          <div class="entry-zone">${e.zone || '-'}</div>
          <div class="entry-main">
            <div class="name">${e.name} <span class="mono" style="font-weight:400;color:var(--ink-soft);font-size:12px;">· ${e.goal || '목표 미정'}</span></div>
            <div class="meta">${e.place ? `<span>${e.place}</span>` : ''}</div>
            <div class="people">${chips.join('')}</div>
          </div>
          <div class="entry-actions">
            <button class="date-edit-btn mono" data-date-toggle="${e.id}" title="일정 변경">📅 ${e.date}</button>
            <input type="date" class="date-edit-input" data-date-input="${e.id}" value="${e.date}" style="display:none;">
            <button class="status-pill status-toggle ${e.status}" data-status-toggle="${e.id}" title="클릭해서 진행 상태 변경">${e.status === 'ongoing' ? '진행' : '중단'}</button>
            <button class="icon-btn" data-remove="${e.id}" title="삭제">✕</button>
          </div>
        </div>`;
    }).join('');
    return `
      <div class="day-group">
        <div class="day-label">${fmtDateLabel(date)}</div>
        <div class="entry-list">${rows}</div>
      </div>`;
  }).join('');

  els.groups.querySelectorAll('[data-remove]').forEach((btn) => {
    btn.addEventListener('click', () => handleRemove(Number(btn.dataset.remove)));
  });

  els.groups.querySelectorAll('[data-status-toggle]').forEach((btn) => {
    btn.addEventListener('click', () => handleStatusToggle(Number(btn.dataset.statusToggle)));
  });

  els.groups.querySelectorAll('[data-date-toggle]').forEach((btn) => {
    btn.addEventListener('click', () => {
      const id = btn.dataset.dateToggle;
      const input = els.groups.querySelector(`[data-date-input="${id}"]`);
      btn.style.display = 'none';
      input.style.display = 'inline-block';
      input.focus();
    });
  });

  els.groups.querySelectorAll('[data-date-input]').forEach((input) => {
    input.addEventListener('change', () => handleDateChange(Number(input.dataset.dateInput), input.value));
    input.addEventListener('blur', () => {
      // 변경 없이 포커스만 벗어난 경우 원래 버튼으로 되돌림
      const id = input.dataset.dateInput;
      const btn = els.groups.querySelector(`[data-date-toggle="${id}"]`);
      if (btn && input.style.display !== 'none') {
        input.style.display = 'none';
        btn.style.display = 'inline-flex';
      }
    });
  });
}

async function handleStatusToggle(id) {
  const entry = entries.find((e) => e.id === id);
  if (!entry) return;
  const prevStatus = entry.status;
  const nextStatus = prevStatus === 'ongoing' ? 'stopped' : 'ongoing';
  entry.status = nextStatus;
  render();
  try {
    await outreachApi.update(id, { status: nextStatus });
  } catch (err) {
    entry.status = prevStatus;
    render();
    alert(`상태 변경 실패: ${err.message}`);
  }
}

async function handleDateChange(id, newDate) {
  const entry = entries.find((e) => e.id === id);
  if (!entry || !newDate || newDate === entry.date) {
    render();
    return;
  }
  const prevDate = entry.date;
  entry.date = newDate;
  render();
  try {
    await outreachApi.update(id, { date: newDate });
  } catch (err) {
    entry.date = prevDate;
    render();
    alert(`일정 변경 실패: ${err.message}`);
  }
}

async function handleRemove(id) {
  const prev = entries;
  entries = entries.filter((e) => e.id !== id);
  render();
  try {
    await outreachApi.remove(id);
  } catch (err) {
    entries = prev; // 실패 시 롤백
    render();
    alert(`삭제 실패: ${err.message}`);
  }
}

function resetForm() {
  ['of-zone', 'of-name', 'of-counselor1', 'of-counselor2', 'of-place', 'of-goal'].forEach((id) => {
    document.getElementById(id).value = '';
  });
  els.error.classList.remove('show');
}

async function handleSave() {
  const date = els.date.value;
  const zone = els.zone.value.trim();
  const name = els.name.value.trim();
  const counselor1 = els.c1.value.trim();
  const counselor2 = els.c2.value.trim();
  const place = els.place.value.trim();
  const goal = els.goal.value.trim();
  const status = els.status.value;

  if (!counselor1) {
    els.error.textContent = '상담자 이름은 필수 입력입니다.';
    els.error.classList.add('show');
    return;
  }
  if (!date || !zone || !name) {
    els.error.textContent = '날짜 · 구역 · 명단은 필수 입력입니다.';
    els.error.classList.add('show');
    return;
  }
  els.error.classList.remove('show');

  const input = { date, zone, name, counselor1, counselor2: counselor2 || null, place, goal, status };

  els.saveBtn.disabled = true;
  try {
    const created = await outreachApi.create(input);
    entries.push(created);
  } catch (err) {
    // 백엔드가 아직 없을 때도 로컬에서 확인할 수 있도록 낙관적으로 추가
    entries.push({ id: Date.now(), ...input });
    els.error.textContent = `저장은 로컬에만 반영됐습니다 (API 오류: ${err.message})`;
    els.error.classList.add('show');
  } finally {
    els.saveBtn.disabled = false;
  }

  resetForm();
  els.form.classList.remove('open');
  render();
}

export async function initOutreachTab() {
  cacheEls();

  els.toggleBtn.addEventListener('click', () => els.form.classList.add('open'));
  els.cancelBtn.addEventListener('click', () => {
    els.form.classList.remove('open');
    resetForm();
  });
  els.saveBtn.addEventListener('click', handleSave);

  els.groups.innerHTML = '<div class="loading">불러오는 중…</div>';
  try {
    entries = await outreachApi.list();
    loadFailed = false;
  } catch (err) {
    loadFailed = true;
    entries = [];
  }
  render();
}
