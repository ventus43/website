import { scheduleApi } from '../api.js';
import { fmtMonthShort } from '../utils.js';

let entries = [];
let loadFailed = false;

const els = {};

function cacheEls() {
  els.list = document.getElementById('schedule-list');
  els.count = document.getElementById('count-schedule');
  els.form = document.getElementById('schedule-form');
  els.toggleBtn = document.getElementById('toggle-schedule-form');
  els.cancelBtn = document.getElementById('cancel-schedule');
  els.saveBtn = document.getElementById('save-schedule');
  els.error = document.getElementById('schedule-error');
  els.date = document.getElementById('sf-date');
  els.time = document.getElementById('sf-time');
  els.title = document.getElementById('sf-title');
  els.place = document.getElementById('sf-place');
  els.memo = document.getElementById('sf-memo');
}

function render() {
  els.count.textContent = entries.length;

  if (loadFailed && entries.length === 0) {
    els.list.innerHTML = `<div class="error-banner">일정 목록을 불러오지 못했습니다. API 서버 연결을 확인해 주세요.</div>`;
    return;
  }

  if (entries.length === 0) {
    els.list.innerHTML = '<div class="empty">등록된 일정이 없습니다. 위 + 버튼으로 추가해 보세요.</div>';
    return;
  }

  const sorted = [...entries].sort((a, b) => (a.date || '').localeCompare(b.date || ''));
  els.list.innerHTML = sorted.map((s) => {
    const d = s.date ? new Date(`${s.date}T00:00:00`) : null;
    return `
      <div class="sched-card" data-id="${s.id}">
        <div class="sched-date">
          <div class="d">${d ? d.getDate() : '–'}</div>
          <div class="m">${d ? fmtMonthShort(s.date) : '미정'}</div>
        </div>
        <div class="sched-main">
          <div class="title">${s.title}</div>
          <div class="meta">
            ${s.time ? `<span>${s.time}</span>` : ''}
            ${s.place ? `<span>${s.place}</span>` : ''}
            ${s.memo ? `<span>${s.memo}</span>` : ''}
          </div>
        </div>
        <div class="entry-actions">
          <button class="icon-btn" data-remove="${s.id}" title="삭제">✕</button>
        </div>
      </div>`;
  }).join('');

  els.list.querySelectorAll('[data-remove]').forEach((btn) => {
    btn.addEventListener('click', () => handleRemove(Number(btn.dataset.remove)));
  });
}

async function handleRemove(id) {
  const prev = entries;
  entries = entries.filter((s) => s.id !== id);
  render();
  try {
    await scheduleApi.remove(id);
  } catch (err) {
    entries = prev;
    render();
    alert(`삭제 실패: ${err.message}`);
  }
}

function resetForm() {
  ['sf-time', 'sf-title', 'sf-place', 'sf-memo'].forEach((id) => {
    document.getElementById(id).value = '';
  });
  els.error.classList.remove('show');
}

async function handleSave() {
  const date = els.date.value;
  const time = els.time.value;
  const title = els.title.value.trim();
  const place = els.place.value.trim();
  const memo = els.memo.value.trim();

  if (!date || !title) {
    els.error.textContent = '날짜와 제목은 필수 입력입니다.';
    els.error.classList.add('show');
    return;
  }
  els.error.classList.remove('show');

  const input = { date, time, title, place, memo };

  els.saveBtn.disabled = true;
  try {
    const created = await scheduleApi.create(input);
    entries.push(created);
  } catch (err) {
    entries.push({ id: Date.now(), ...input });
    els.error.textContent = `저장은 로컬에만 반영됐습니다 (API 오류: ${err.message})`;
    els.error.classList.add('show');
  } finally {
    els.saveBtn.disabled = false;
  }

  resetForm();
  els.form.classList.remove('open');
  render();
}

export async function initScheduleTab() {
  cacheEls();

  els.toggleBtn.addEventListener('click', () => els.form.classList.add('open'));
  els.cancelBtn.addEventListener('click', () => {
    els.form.classList.remove('open');
    resetForm();
  });
  els.saveBtn.addEventListener('click', handleSave);

  els.list.innerHTML = '<div class="loading">불러오는 중…</div>';
  try {
    entries = await scheduleApi.list();
    loadFailed = false;
  } catch (err) {
    loadFailed = true;
    entries = [];
  }
  render();
}
