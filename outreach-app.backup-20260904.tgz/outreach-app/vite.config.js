import { defineConfig } from 'vite';

export default defineConfig({
  server: {
    port: 5173,
    proxy: {
      // 개발 중 백엔드 API로 프록시. 실제 API 서버 주소로 교체하세요.
      '/api': {
        target: 'http://localhost:8080',
        changeOrigin: true
      }
    }
  }
});
